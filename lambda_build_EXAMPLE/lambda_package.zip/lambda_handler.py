import json
import os
import boto3
from db_insert import insert_obras, insert_videos, insert_alertas, conectar
from datetime import datetime

def validar_variaveis():
    variaveis_esperadas = ["DB_HOST", "DB_USER", "DB_PASSWORD", "DB_NAME"]
    faltando = [var for var in variaveis_esperadas if not os.environ.get(var)]
    if faltando:
        raise Exception(f"Variáveis de ambiente faltando: {', '.join(faltando)}")
    print("✅ Todas as variáveis estão presentes.")

def extract_obra_id(object_key):
    return object_key.split('/')[0]  # Exemplo: extrai "obra001" de "obra001/video123.mp4"

def lambda_handler(event, context):
    # ✅ Validação de variáveis
    validar_variaveis()

    # 📦 Extração de metadados do evento do S3
    record = event['Records'][0]
    bucket = record['s3']['bucket']['name']
    object_key = record['s3']['object']['key']
    obra_id = extract_obra_id(object_key)
    video_path = f"s3://{bucket}/{object_key}"

    # 🗓️ Metadados da obra — por enquanto simulados
    nome = f"Obra {obra_id}"
    localizacao = "Local padrão"
    inicio = datetime(2025, 8, 4).date()
    fim = datetime(2025, 12, 31).date()

    # 🔌 Conexão com o banco
    conn, cursor = conectar()

    try:
        # 🛠️ Inserção de dados
        insert_obras(cursor, conn, nome, localizacao, inicio, fim)
        insert_videos(cursor, conn, obra_id, video_path, datetime.utcnow(), False)

        # ⚠️ ALERTA — simulando uso do video como referência
        insert_alertas(cursor, conn, analise_id=1, tipo="upload", descricao="Novo vídeo recebido", nivel="médio")
    
    except Exception as e:
        print(f"[lambda_handler] Erro: {e}")
    
    finally:
        cursor.close()
        conn.close()

    return {
        'statusCode': 200,
        'body': json.dumps(f'Dados inseridos com sucesso para obra {obra_id}!')
    }